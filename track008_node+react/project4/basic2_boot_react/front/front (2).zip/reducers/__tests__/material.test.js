import reducer, {
  initialState,
  CREATE_MATERIAL_RESET,
  UPDATE_MATERIAL_RESET,
  fetchMaterialsRequest,
  fetchMaterialsSuccess,
  fetchMaterialsFailure,
  createMaterialRequest,
  createMaterialSuccess,
  updateMaterialSuccess,
  deleteMaterialSuccess,
} from '../materialReducer';

describe('Material Reducer', () => {
  // 1. 초기 상태 테스트
  it('should return the initial state', () => {
    expect(reducer(undefined, { type: undefined })).toEqual(initialState);
  });

  // 2. 초기화 액션 테스트
  it('CREATE_MATERIAL_RESET: 등록 완료 상태를 초기화해야 한다', () => {
    const prevState = { ...initialState, createMaterialDone: true, error: 'error' };
    const state = reducer(prevState, CREATE_MATERIAL_RESET());
    expect(state.createMaterialDone).toBe(false);
    expect(state.error).toBeNull();
  });

  // 3. 조회(Read) 테스트
  describe('Fetch Materials', () => {
    it('fetchMaterialsRequest: 로딩 상태를 true로 변경해야 한다', () => {
      const state = reducer(initialState, fetchMaterialsRequest());
      expect(state.loading).toBe(true);
      expect(state.error).toBeNull();
    });

    it('fetchMaterialsSuccess: 데이터를 저장하고 로딩을 종료해야 한다', () => {
      const dummyData = [
        { materialid: 1, title: '고구마', category: '구황작물' },
        { materialid: 2, title: '감자', category: '구황작물' },
      ];
      const state = reducer(initialState, fetchMaterialsSuccess(dummyData));
      expect(state.loading).toBe(false);
      expect(state.materials).toEqual(dummyData);
    });

    it('fetchMaterialsFailure: 에러 메시지를 저장해야 한다', () => {
      const errorMsg = '서버 에러 발생';
      const state = reducer(initialState, fetchMaterialsFailure(errorMsg));
      expect(state.loading).toBe(false);
      expect(state.error).toBe(errorMsg);
    });
  });

  // 4. 생성(Create) 테스트
  it('createMaterialSuccess: 새로운 식재료를 배열 맨 앞에 추가해야 한다', () => {
    const prevState = { 
      ...initialState, 
      materials: [{ materialid: 1, title: '기존 재료' }] 
    };
    const newMaterial = { materialid: 2, title: '신규 재료' };
    const state = reducer(prevState, createMaterialSuccess(newMaterial));
    
    expect(state.createMaterialDone).toBe(true);
    expect(state.materials[0]).toEqual(newMaterial);
    expect(state.materials.length).toBe(2);
  });

  // 5. 수정(Update) 테스트
  it('updateMaterialSuccess: 해당 ID의 데이터를 수정해야 한다', () => {
    const prevState = {
      ...initialState,
      materials: [
        { materialid: 1, title: '오이', category: '채소' },
        { materialid: 2, title: '당근', category: '채소' },
      ],
      currentMaterial: { materialid: 1, title: '오이' }
    };
    const updatedMaterial = { materialid: 1, title: '맛있는 오이', category: '채소' };
    const state = reducer(prevState, updateMaterialSuccess(updatedMaterial));

    expect(state.updateMaterialDone).toBe(true);
    expect(state.materials.find(m => m.materialid === 1).title).toBe('맛있는 오이');
    expect(state.currentMaterial.title).toBe('맛있는 오이');
  });

  // 6. 삭제(Delete) 테스트
  it('deleteMaterialSuccess: 해당 ID의 데이터를 목록에서 제거해야 한다', () => {
    const prevState = {
      ...initialState,
      materials: [{ materialid: 1, title: '삭제될 재료' }],
      deleteMaterialDone: false,
    };
    const state = reducer(prevState, deleteMaterialSuccess(1)); // payload: materialid

    expect(state.deleteMaterialDone).toBe(true);
    expect(state.materials.length).toBe(0);
  });
});