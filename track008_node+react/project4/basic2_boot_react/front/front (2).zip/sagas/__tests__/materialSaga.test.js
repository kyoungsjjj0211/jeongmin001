import { runSaga } from 'redux-saga';
import axios from '../../api/axios';
import {
  fetchMaterials,
  fetchMaterialsPaged,
  createMaterial,
  deleteMaterial
} from '../materialSaga';

import {
  fetchMaterialsSuccess,
  fetchMaterialsFailure,
  fetchMaterialsPagedSuccess,
  createMaterialSuccess,
  deleteMaterialSuccess
} from '../../reducers/materialReducer';

// axios 모킹
jest.mock('../../api/axios');

describe('Material Saga Tests', () => {
  
  // 1. 전체 조회 테스트
  it('fetchMaterials: 모든 식재료 조회 성공 시 SUCCESS 액션을 디스패치해야 한다', async () => {
    const dummyData = [{ materialid: 1, title: '배추' }];
    axios.get.mockResolvedValue({ data: dummyData });

    const dispatched = [];
    await runSaga(
      { dispatch: (action) => dispatched.push(action) },
      fetchMaterials
    ).toPromise();

    expect(axios.get).toHaveBeenCalledWith('/api/materials/all');
    expect(dispatched).toContainEqual(fetchMaterialsSuccess(dummyData));
  });

  // 2. 페이징 조회 테스트
  it('fetchMaterialsPaged: 페이징 데이터 조회 성공 시 데이터와 페이지 번호를 함께 보내야 한다', async () => {
    const dummyData = [{ materialid: 1, title: '무' }];
    const payload = { keyword: '무', page: 1, size: 10 };
    axios.get.mockResolvedValue({ data: dummyData });

    const dispatched = [];
    await runSaga(
      { dispatch: (action) => dispatched.push(action) },
      fetchMaterialsPaged,
      { payload }
    ).toPromise();

    expect(axios.get).toHaveBeenCalledWith('/api/materials', { params: payload });
    expect(dispatched).toContainEqual(fetchMaterialsPagedSuccess({ data: dummyData, page: 1 }));
  });

  // 3. 생성(FormData) 테스트
  it('createMaterial: FormData 전송 및 등록 성공 시 SUCCESS 액션을 디스패치해야 한다', async () => {
    const dummyResponse = { materialid: 1, title: '당근' };
    const payload = { 
      dto: { title: '당근', category: '채소' }, 
      file: new File([''], 'carrot.png', { type: 'image/png' }) 
    };
    axios.post.mockResolvedValue({ data: dummyResponse });

    const dispatched = [];
    await runSaga(
      { dispatch: (action) => dispatched.push(action) },
      createMaterial,
      { payload }
    ).toPromise();

    expect(axios.post).toHaveBeenCalledWith('/api/materials', expect.any(FormData), {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    expect(dispatched).toContainEqual(createMaterialSuccess(dummyResponse));
  });

  // 4. 삭제 테스트
  it('deleteMaterial: 삭제 성공 시 해당 ID를 SUCCESS 액션에 담아 보내야 한다', async () => {
    const materialid = 1;
    axios.delete.mockResolvedValue({});

    const dispatched = [];
    await runSaga(
      { dispatch: (action) => dispatched.push(action) },
      deleteMaterial,
      { payload: materialid }
    ).toPromise();

    expect(axios.delete).toHaveBeenCalledWith(`/api/materials/${materialid}`);
    expect(dispatched).toContainEqual(deleteMaterialSuccess(materialid));
  });

  // 5. 실패 케이스 테스트
  it('fetchMaterials: API 에러 발생 시 FAILURE 액션을 디스패치해야 한다', async () => {
    const errorMsg = '서버 에러';
    axios.get.mockRejectedValue({
      response: { data: { message: errorMsg } }
    });

    const dispatched = [];
    await runSaga(
      { dispatch: (action) => dispatched.push(action) },
      fetchMaterials
    ).toPromise();

    expect(dispatched).toContainEqual(fetchMaterialsFailure(errorMsg));
  });
});