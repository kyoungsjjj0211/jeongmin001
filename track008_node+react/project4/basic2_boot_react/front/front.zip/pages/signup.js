// 1. import 역할 주석
import React, { useState, useEffect } from "react"; // view 상태관리 (이벤트, 변수)
import { useRouter } from "next/router"; // 경로 이동
import { useDispatch, useSelector } from "react-redux"; // 리듀서 상태관리
import { Row, Col, Form, Input, Button, Upload, Spin, message } from "antd"; // Ant Design 컴포넌트
import { UploadOutlined, PlusOutlined } from "@ant-design/icons"; // 아이콘 (PlusOutlined 추가)
import { signupRequest, resetAuthState } from "../reducers/authReducer"; // 액션 함수
import axios from "../api/axios"; // API 통신 설정 (BaseURL, Interceptors 등)

// Ant Design Upload 필터 함수 (파일 리스트 구조 맞춤)
const normFile = (e) => {
    if (Array.isArray(e)) return e;
    return e?.fileList;
};

export default function Mypage() {
    // 부품 사용 가능하게 router, dispatch 초기화
    const dispatch = useDispatch();
    const router = useRouter();

    // Redux 스토어에서 상태 가져오기 (회원가입 로딩, 에러, 완료 여부)
    const { signupLoading: loading, signupError: error, signupDone: success } = useSelector((state) => state.auth);

    // 파일 업로드 상태 관리 (미리보기 및 전송용)
    const [fileList, setFileList] = useState([]);

    // 폼 제출 함수 (회원가입 버튼 클릭 시)
    const onFinish = (values) => {
        const formData = new FormData();
        formData.append("email", values.email);
        formData.append("password", values.password);
        formData.append("nickname", values.nickname);
        formData.append("provider", "local"); // 로컬 회원가입 구분자
        
        // 파일이 있을 경우 전송 데이터에 추가
        if (fileList.length > 0) {
            formData.append("ufile", fileList[0].originFileObj);
        }
        
        // Redux-Saga/Thunk 액션 실행
        dispatch(signupRequest(formData));
    };

    // 업로드 파일 리스트 변경 핸들러
    const handleChange = ({ fileList: newFileList }) => setFileList(newFileList);

    // 회원가입 성공 감시: 성공 시 메세지 출력 후 로그인 페이지로 이동
    useEffect(() => {
        if (success) {
            message.success("회원가입이 성공적으로 완료되었습니다.");
            router.push("/login");
            // 성공 상태 리셋 (다시 회원가입 페이지 올 때를 대비)
            dispatch(resetAuthState());
        }
    }, [success, router, dispatch]);

    return (
        <Row justify="center" style={{ marginTop: 40 }}>
            <Col xs={24} sm={16} md={8}>
                {/* 로딩 중일 때 화면 중앙 스피너 표시 */}
                {loading && (
                    <div style={{ textAlign: 'center', marginBottom: 20 }}>
                        <Spin size="large" tip="처리 중..." />
                    </div>
                )}
                
                {/* 리듀서에서 넘어온 에러 메시지 표시 */}
                {error && <p style={{ color: "red", textAlign: "center" }}>{error}</p>}

                {/* 가입 성공 전까지만 폼을 보여줌 */}
                {!success && (
                    <Form onFinish={onFinish} layout="vertical">
                        {/* 1. 이메일 입력 및 실시간 중복 검사 */}
                        <Form.Item
                            label="이메일"
                            name="email"
                            hasFeedback
                            rules={[
                                { required: true, message: '이메일을 입력하세요.' },
                                { type: 'email', message: '이메일 형식이 아닙니다.' },
                                {
                                    validator: async (_, value) => {
                                        if (!value) return Promise.resolve();
                                        try {
                                            const res = await axios.get(`/auth/check-email?email=${encodeURIComponent(value)}`);
                                            if (res?.data === true) {
                                                return Promise.reject(new Error("이미 사용 중인 이메일입니다."));
                                            }
                                            return Promise.resolve();
                                        } catch (err) {
                                            return Promise.reject(new Error("중복 검사 실패"));
                                        }
                                    },
                                }
                            ]}
                        >
                            <Input placeholder="example@email.com" />
                        </Form.Item>

                        {/* 2. 비밀번호 입력 */}
                        <Form.Item
                            label="비밀번호"
                            name="password"
                            rules={[{ required: true, message: '비밀번호를 입력하세요.' }]}
                        >
                            <Input.Password />
                        </Form.Item>

                        {/* 3. 닉네임 입력 및 실시간 중복 검사 */}
                        <Form.Item
                            label="닉네임"
                            name="nickname"
                            hasFeedback
                            rules={[
                                { required: true, message: '닉네임을 입력하세요.' },
                                {
                                    validator: async (_, value) => {
                                        if (!value) return Promise.resolve();
                                        try {
                                            const res = await axios.get(`/auth/check-nickname?nickname=${encodeURIComponent(value)}`);
                                            if (res?.data === true) {
                                                return Promise.reject(new Error("이미 사용 중인 닉네임입니다."));
                                            }
                                            return Promise.resolve();
                                        } catch (err) {
                                            return Promise.reject(new Error("중복 검사 실패"));
                                        }
                                    },                                
                                }
                            ]}
                        >
                            <Input />
                        </Form.Item>

                        {/* 4. 프로필 이미지 업로드 (1장 제한) */}
                        <Form.Item 
                            label="프로필 이미지" 
                            valuePropName="fileList" 
                            getValueFromEvent={normFile}
                        >
                            <Upload 
                                listType="picture-card"
                                fileList={fileList}
                                onChange={handleChange}
                                beforeUpload={() => false} // 자동 업로드 방지
                            >
                                {fileList.length < 1 && (
                                    <button style={{ border: 0, background: 'none', cursor: 'pointer' }} type="button">
                                        <PlusOutlined />
                                        <div style={{ marginTop: 8 }}>Upload</div>
                                    </button>
                                )}
                            </Upload>
                        </Form.Item>

                        {/* 5. 제출 버튼 */}
                        <Form.Item>
                            <Button type="primary" htmlType="submit" loading={loading} block>
                                회원가입
                            </Button>
                        </Form.Item>
                    </Form>
                )}
            </Col>
        </Row>
    );
}