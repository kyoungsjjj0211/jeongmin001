package com.thejoa703.service;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.thejoa703.dao.FoodDao;
import com.thejoa703.dto.FoodDto;

public class FoodDetail implements FoodService {

	@Override
	public void exec(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//데이터 넘겨받기
		//이건 MbtiDetail에서처럼 조회수를 1 올리는 기능이 아닌 원래 있던 정보를 상세보기 하는 기능인데
		int id=Integer.parseInt(request.getParameter("id"));
		
		//드커프리
		FoodDao dao = new FoodDao();
		FoodDto result = dao.select(id);
		
		request.setAttribute("dto", result);
		

		//데이터 넘겨주기
	
	}

}
