package com.company.portfolio_game;

import java.util.List;

import com.company.portfolio_game.CharacterInfo;

public interface Gamecontroller {
	int exec(List<CharacterInfo> characters, int find);
}
